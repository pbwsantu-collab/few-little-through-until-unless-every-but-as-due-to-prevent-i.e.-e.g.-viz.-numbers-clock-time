//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DpR68w6d.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/practice",
			"/progress",
			"/reference",
			"/words",
			"/lessons/$id"
		],
		preloads: [
			"/assets/index-DuvAlR5S.js",
			"/assets/jsx-runtime-Cltr0gcK.js",
			"/assets/link-CY_3yKXA.js",
			"/assets/preload-helper-Lju6IjGL.js",
			"/assets/createLucideIcon-CSACGEBt.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DuvAlR5S.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BMZshVJ2.js",
			"/assets/lessons-pk6WD7SK.js",
			"/assets/questions-FskpycvG.js",
			"/assets/pos-words-KddmHyIr.js",
			"/assets/progress-BTZqUmJj.js"
		]
	},
	"/practice": {
		filePath: "/workspace/src/routes/practice.tsx",
		children: void 0,
		preloads: [
			"/assets/practice-CKrSjPAW.js",
			"/assets/lessons-pk6WD7SK.js",
			"/assets/questions-FskpycvG.js",
			"/assets/progress-BTZqUmJj.js",
			"/assets/button-B3-WHfdt.js"
		]
	},
	"/progress": {
		filePath: "/workspace/src/routes/progress.tsx",
		children: void 0,
		preloads: [
			"/assets/progress-B48YjJcm.js",
			"/assets/lessons-pk6WD7SK.js",
			"/assets/questions-FskpycvG.js",
			"/assets/progress-BTZqUmJj.js"
		]
	},
	"/reference": {
		filePath: "/workspace/src/routes/reference.tsx",
		children: void 0,
		preloads: [
			"/assets/reference-C-FA07VV.js",
			"/assets/rule-block-DQ0-XzEC.js",
			"/assets/lessons-pk6WD7SK.js"
		]
	},
	"/words": {
		filePath: "/workspace/src/routes/words.tsx",
		children: void 0,
		preloads: [
			"/assets/words-ozPGHGBs.js",
			"/assets/pos-words-KddmHyIr.js",
			"/assets/progress-BTZqUmJj.js"
		]
	},
	"/lessons/$id": {
		filePath: "/workspace/src/routes/lessons.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/lessons._id-BLUn_sie.js",
			"/assets/rule-block-DQ0-XzEC.js",
			"/assets/lessons-pk6WD7SK.js",
			"/assets/progress-BTZqUmJj.js",
			"/assets/button-B3-WHfdt.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
