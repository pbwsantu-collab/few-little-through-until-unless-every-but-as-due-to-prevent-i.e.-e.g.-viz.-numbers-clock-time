import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as cn, r as Route$4 } from "./router-DKzWdXd5.mjs";
import { n as chapters } from "./lessons-DRFcRenz.mjs";
import { t as useProgress } from "./progress-C8Qtyf51.mjs";
import { t as Button } from "./button-Bh4bdQ9H.mjs";
import { t as questions } from "./questions-CGg4OiG9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/practice-DALM0R5c.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Practice() {
	const { chapter } = Route$4.useSearch();
	const [filter, setFilter] = (0, import_react.useState)(chapter ?? "all");
	const [i, setI] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const save = useProgress((s) => s.saveAnswer);
	const resetQuiz = useProgress((s) => s.resetQuiz);
	const quiz = useProgress((s) => s.quiz);
	const list = (0, import_react.useMemo)(() => filter === "all" ? questions : questions.filter((q) => q.chapterId === filter), [filter]);
	const q = list[Math.min(i, list.length - 1)];
	const revealed = picked !== null;
	const isCorrect = picked === q?.answer;
	const answeredCount = list.filter((item) => quiz[item.id]).length;
	const correctCount = list.filter((item) => quiz[item.id]?.correct).length;
	if (!q) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-semibold",
			children: "১৫০টি প্রশ্ন"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "bn mt-2 text-muted",
			children: "বইয়ের অনুশীলনী ৩৮–৪৩ এবং প্রতিটি ব্যতিক্রম ঢোকানো হয়েছে। উত্তর স্থানীয়ভাবে সংরক্ষিত।"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("h-9 rounded-md px-3 text-sm", filter === "all" ? "bg-primary text-primary-fg" : "bg-surface border border-border"),
				onClick: () => {
					setFilter("all");
					setI(0);
					setPicked(null);
				},
				children: "সব"
			}), chapters.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("h-9 rounded-md px-3 text-sm", filter === c.id ? "bg-primary text-primary-fg" : "bg-surface border border-border"),
				onClick: () => {
					setFilter(c.id);
					setI(0);
					setPicked(null);
				},
				children: c.index
			}, c.id))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-sm text-muted tabular-nums",
			children: [
				"প্রশ্ন ",
				i + 1,
				" / ",
				list.length,
				" · সঠিক ",
				correctCount,
				"/",
				answeredCount
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 h-1.5 overflow-hidden rounded-full bg-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-primary",
				style: { width: `${(i + 1) / list.length * 100}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 rounded-xl border border-border bg-surface p-5 shadow-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-primary",
					children: ["প্রশ্ন ", q.id]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "bn mt-2 text-lg leading-relaxed",
					children: q.stemBn
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-medium",
					children: q.stem
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-2",
					children: q.options.map((opt) => {
						const show = revealed && (opt === q.answer || opt === picked);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: revealed,
							onClick: () => {
								setPicked(opt);
								save(q.id, opt, opt === q.answer);
							},
							className: cn("w-full rounded-md border px-3 py-3 text-left text-sm min-h-11", !show && "border-border bg-bg hover:border-border-strong", revealed && opt === q.answer && "border-ok bg-ok-soft text-ok", revealed && opt === picked && opt !== q.answer && "border-bad bg-bad-soft text-bad"),
							children: opt
						}) }, opt);
					})
				}),
				revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("mt-4 rounded-md p-3 text-sm", isCorrect ? "bg-ok-soft text-ok" : "bg-bad-soft text-bad"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "bn font-medium",
						children: [
							isCorrect ? "সঠিক।" : "ভুল।",
							" ",
							q.whyBn
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 opacity-90",
						children: q.whyEn
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						disabled: i === 0,
						onClick: () => {
							setI((n) => Math.max(0, n - 1));
							setPicked(null);
						},
						children: "আগেরটি"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						disabled: i >= list.length - 1,
						onClick: () => {
							setI((n) => Math.min(list.length - 1, n + 1));
							setPicked(null);
						},
						children: "পরেরটি"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-6 text-sm text-muted underline",
			onClick: () => resetQuiz(),
			children: "স্কোর মুছুন"
		})
	] });
}
//#endregion
export { Practice as component };
