import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Check, r as TriangleAlert, t as X } from "../_libs/lucide-react.mjs";
import { i as cn } from "./router-DKzWdXd5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rule-block-DsX2vrq5.js
var import_jsx_runtime = require_jsx_runtime();
function RuleBlock({ section }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl border border-border bg-surface p-5 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-primary",
				children: section.article
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-1 font-display text-xl font-semibold text-ink",
				children: section.titleEn
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "bn mt-0.5 text-base text-muted",
				children: section.titleBn
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "bn mt-4 text-[1.05rem] leading-relaxed text-ink",
				children: section.ideaBn
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: section.ideaEn
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-3",
				children: section.bullets.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-md bg-bg px-3 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "bn text-[0.98rem] text-ink",
						children: b.bn
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: b.en
					})]
				}, b.en))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-2",
				children: section.examples.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("flex gap-2 rounded-md px-3 py-2 text-sm", ex.ok ? "bg-ok-soft text-ok" : "bg-bad-soft text-bad"),
					children: [ex.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-medium",
							children: [
								ex.ok ? "সঠিক" : "ভুল",
								" — ",
								ex.en
							]
						}),
						ex.bn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "bn mt-0.5 opacity-90",
							children: ex.bn
						}) : null,
						ex.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "bn mt-1 text-xs",
							children: ex.note
						}) : null
					] })]
				}, ex.en))
			}),
			section.exceptions?.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "mt-4 rounded-lg border border-warn/30 bg-warn-soft p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 text-sm font-semibold text-warn",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4" }),
							"ব্যতিক্রম · ",
							ex.titleBn
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "bn mt-2 text-sm leading-relaxed text-ink",
						children: ex.bodyBn
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: ex.bodyEn
					}),
					ex.examples?.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: cn("mt-2 text-sm", e.ok ? "text-ok" : "text-bad"),
						children: [
							e.ok ? "✓" : "✗",
							" ",
							e.en
						]
					}, e.en))
				]
			}, ex.titleEn))
		]
	});
}
//#endregion
export { RuleBlock as t };
