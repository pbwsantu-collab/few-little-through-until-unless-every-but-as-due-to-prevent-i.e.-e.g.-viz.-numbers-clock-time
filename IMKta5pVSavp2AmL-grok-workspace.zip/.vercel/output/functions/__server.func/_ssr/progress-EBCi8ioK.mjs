import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as chapters } from "./lessons-DRFcRenz.mjs";
import { t as useProgress } from "./progress-C8Qtyf51.mjs";
import { t as questions } from "./questions-CGg4OiG9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/progress-EBCi8ioK.js
var import_jsx_runtime = require_jsx_runtime();
function ProgressPage() {
	const completed = useProgress((s) => s.completedLessons);
	const quiz = useProgress((s) => s.quiz);
	const bookmarks = useProgress((s) => s.bookmarks);
	const answered = Object.keys(quiz).length;
	const correct = Object.values(quiz).filter((x) => x.correct).length;
	const weak = questions.filter((q) => quiz[q.id] && !quiz[q.id].correct);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-semibold",
			children: "অগ্রগতি"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "bn mt-2 text-muted",
			children: "স্কোর এই ডিভাইসেই থাকে — সাইন-ইন লাগে না।"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "পড়া অধ্যায়",
					value: `${completed.length}/${chapters.length}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "উত্তর দেওয়া",
					value: `${answered}/150`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "সঠিক",
					value: `${correct}/${answered || 0}`
				})
			]
		}),
		bookmarks.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-sm",
			children: [
				"বুকমার্ক: ",
				bookmarks.join(", "),
				" — ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/words",
					className: "text-primary",
					children: "পদ তালিকা"
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display mt-8 text-xl font-semibold",
			children: "দুর্বল প্রশ্ন"
		}),
		weak.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "এখনো ভুল নেই, অথবা অনুশীলন শুরু হয়নি।"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-2",
			children: weak.slice(0, 20).map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-md border border-border bg-surface p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-primary",
						children: ["#", q.id]
					}),
					" ",
					q.stem
				]
			}, q.id))
		})
	] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display mt-1 text-2xl tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { ProgressPage as component };
