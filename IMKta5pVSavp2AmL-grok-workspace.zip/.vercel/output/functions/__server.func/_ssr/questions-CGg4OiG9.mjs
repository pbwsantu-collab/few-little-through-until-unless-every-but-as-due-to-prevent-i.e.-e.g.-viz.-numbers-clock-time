//#region node_modules/.nitro/vite/services/ssr/assets/questions-CGg4OiG9.js
function q(id, chapterId, stem, stemBn, options, answer, whyEn, whyBn, type = "choice") {
	return {
		id,
		chapterId,
		type,
		stem,
		stemBn,
		options,
		answer,
		whyEn,
		whyBn
	};
}
var questions = [
	q(1, "few-little", "I have ___ friends here. (practically none)", "এখানে বন্ধু প্রায় নেই।", [
		"few",
		"a few",
		"the few",
		"not a few"
	], "few", "Few is negative: almost none.", "Few = প্রায় কেউই নেই।"),
	q(2, "few-little", "Give me ___ more biscuits. (some)", "কিছু বিস্কুট চাই।", [
		"few",
		"a few",
		"the few",
		"little"
	], "a few", "A few = some, opposed to none.", "A few = কিছু আছে।"),
	q(3, "few-little", "___ friends I had left me.", "যে অল্প বন্ধু ছিল তারা চলে গেল।", [
		"Few",
		"A few",
		"The few",
		"Not a few"
	], "The few", "The few = all of the small number that existed.", "The few = যা ছিল তার সব।"),
	q(4, "few-little", "He gave me ___ cakes. (a pretty large number)", "কম নয়, অনেক কেক।", [
		"few",
		"a few",
		"the few",
		"not a few"
	], "not a few", "Not a few = many.", "Not a few = অনেক।"),
	q(5, "few-little", "He has ___ time to spare. (almost none)", "ফাঁকা সময় প্রায় নেই।", [
		"few",
		"little",
		"a little",
		"the little"
	], "little", "Little is negative quantity.", "Little = প্রায় কিছুই নেই।"),
	q(6, "few-little", "I want ___ sugar.", "অল্প চিনি চাই।", [
		"little",
		"a little",
		"few",
		"a few"
	], "a little", "A little = a small quantity, affirmative.", "A little = অল্প পরিমাণ আছে।"),
	q(7, "few-little", "___ hope I had is gone.", "যেটুকু আশা ছিল তাও শেষ।", [
		"Little",
		"A little",
		"The little",
		"Not a little"
	], "The little", "The little = all the small amount that existed.", "The little = যা ছিল তার সবটা।"),
	q(8, "few-little", "He gave me ___ trouble. (much)", "অনেক ঝামেলা।", [
		"little",
		"a little",
		"not a little",
		"few"
	], "not a little", "Not a little = much.", "Not a little = অনেক।"),
	q(9, "few-little", "Give me ___ ink that I may write ___ more pages.", "কালি ও আরও কয়েক পাতা।", [
		"a little / a few",
		"little / few",
		"a few / a little",
		"few / little"
	], "a little / a few", "Ink is quantity (a little); pages are number (a few).", "কালি = a little; পাতা = a few।"),
	q(10, "few-little", "There were no ___ than fifty members present.", "পঞ্চাশের কম নয়।", [
		"less",
		"fewer",
		"lesser",
		"few"
	], "fewer", "Number takes fewer in school grammar.", "সংখ্যায় fewer।"),
	q(11, "few-little", "This is of ___ importance.", "কম গুরুত্বপূর্ণ।", [
		"less",
		"fewer",
		"lesser",
		"least"
	], "lesser", "Lesser is attributive: less important.", "Lesser = কম গুরুত্বপূর্ণ।"),
	q(12, "few-little", "I care ___ for him. (almost not at all)", "তার জন্য প্রায় কিছুই ভাবি না।", [
		"few",
		"little",
		"a little",
		"not a little"
	], "little", "Little as adverb of degree, negative.", "Little = প্রায় না।"),
	q(13, "few-little", "You can expect ___ more men.", "আরও কিছু মানুষ আশা করা যায়।", [
		"few",
		"a few",
		"little",
		"a little"
	], "a few", "Men are countable.", "মানুষ গণনীয় — a few।"),
	q(14, "few-little", "Choose the correct sentence.", "সঠিক বাক্য বেছে নিন।", [
		"There were no less than fifty men there.",
		"There were no fewer than fifty men there.",
		"There were no lesser than fifty men there.",
		"There were no little than fifty men there."
	], "There were no fewer than fifty men there.", "Safe rule: fewer for number.", "সংখ্যায় fewer।"),
	q(15, "few-little", "Less joy, less meat, fewer books — which is wrong if we say:", "কোনটি ভুল?", [
		"less rain",
		"less time",
		"less girls",
		"less money"
	], "less girls", "Girls are countable: fewer girls.", "মেয়ে = সংখ্যা, fewer girls।"),
	q(16, "quantity-words", "A lot of time ___ needed to learn a language.", "সময় লাগে।", [
		"is",
		"are",
		"were",
		"have"
	], "is", "Agreement follows time (singular), not lot.", "কর্তা time — একবচন।"),
	q(17, "quantity-words", "A lot of my friends ___ to emigrate.", "বন্ধুরা চায়।", [
		"wants",
		"want",
		"is wanting",
		"has wanted"
	], "want", "Friends is plural.", "কর্তা friends — বহুবচন।"),
	q(18, "quantity-words", "I have seen him lots of ___.", "অনেকবার।", [
		"time",
		"times",
		"timing",
		"timely"
	], "times", "Time = occasion is countable.", "বার = times।"),
	q(19, "quantity-words", "People say you are wrong. Here people means:", "এখানে people =", [
		"a nation",
		"nations",
		"persons generally",
		"the army"
	], "persons generally", "Bare people = persons, always plural.", "জনসাধারণ।"),
	q(20, "quantity-words", "The Americans are ___ rich people.", "একটি ধনী জাতি।", [
		"a",
		"the",
		"—",
		"an"
	], "a", "A people = a nation.", "A people = জাতি।"),
	q(21, "quantity-words", "Different ___ have different customs.", "নানা জাতি।", [
		"people",
		"peoples",
		"peopled",
		"a people"
	], "peoples", "Peoples = nations.", "Peoples = জাতিসমূহ।"),
	q(22, "quantity-words", "He was ___ Principal of this college. (formerly)", "সাবেক অধ্যক্ষ।", [
		"sometime",
		"some time",
		"sometimes",
		"some-times"
	], "sometime", "Sometime = formerly.", "Sometime = সাবেক।"),
	q(23, "quantity-words", "He comes to me ___. (occasionally)", "মাঝে মাঝে আসে।", [
		"sometime",
		"some time",
		"sometimes",
		"some times"
	], "sometimes", "Sometimes = occasionally.", "Sometimes = মাঝে মাঝে।"),
	q(24, "quantity-words", "We must have rest for ___.", "কিছুক্ষণ বিশ্রাম।", [
		"sometime",
		"some time",
		"sometimes",
		"some times"
	], "some time", "Some time = a period.", "Some time = কিছু সময়।"),
	q(25, "quantity-words", "___ India mourns his death. (correct)", "সারা ভারত শোক করে।", [
		"Whole",
		"All / The whole of",
		"The whole",
		"Wholes"
	], "All / The whole of", "Proper nouns take all or the whole of, never bare whole.", "Proper noun-এ whole একা নয়।"),
	q(26, "quantity-words", "Give him ___ the milk.", "সব দুধ।", [
		"whole",
		"all",
		"all of whole",
		"wholes"
	], "all", "All the milk = quantity with singular.", "All the milk চলে।"),
	q(27, "quantity-words", "Give me ___ mango. (one entire fruit)", "একটা আস্ত আম।", [
		"all",
		"whole",
		"the whole",
		"all the"
	], "the whole", "Whole takes the before a singular common noun.", "The whole mango।"),
	q(28, "much-very-too", "He has ___ money and ___ rupees.", "টাকা ও টাকার নোট।", [
		"many / much",
		"much / many",
		"many / many",
		"much / much"
	], "much / many", "Money uncountable; rupees countable.", "Money = much; rupees = many।"),
	q(29, "much-very-too", "I am ___ happy, and he is ___ happier than before.", "খুশি ও আরও খুশি।", [
		"much / very",
		"very / much",
		"too / very",
		"very / too"
	], "very / much", "Very + positive; much + comparative.", "Positive-এ very, comparative-এ much।"),
	q(30, "much-very-too", "This is a ___ charming sight. He was ___ charmed.", "মনোরম / মুগ্ধ।", [
		"much / very",
		"very / much",
		"too / very",
		"very / too"
	], "very / much", "Very with present participle; much with verbal past participle.", "charming-এ very; charmed-এ much।"),
	q(31, "much-very-too", "I am ___ tired.", "ক্লান্ত।", [
		"much",
		"very",
		"too",
		"enough"
	], "very", "Tired has become a true adjective: very tired.", "Tired এখন বিশেষণ — very tired।"),
	q(32, "much-very-too", "He was ___ late for school, so the school was already over.", "স্কুল শেষ।", [
		"very",
		"much",
		"too",
		"enough"
	], "too", "Too = the limit was passed.", "Too = সীমা ছাড়িয়ে।"),
	q(33, "much-very-too", "He was ___ late, yet he caught the train with difficulty.", "দেরি, তবু ধরেছে।", [
		"too",
		"very",
		"enough",
		"much"
	], "very", "He still attended, so very not too.", "গিয়েছে — very late।"),
	q(34, "much-very-too", "I am strong ___ to walk.", "হাঁটার মতো শক্তি।", [
		"too",
		"very",
		"enough",
		"much"
	], "enough", "Enough = the needed limit is reached.", "Enough = যতটা দরকার।"),
	q(35, "much-very-too", "This room is ___ hot for me to remain in it.", "এত গরম যে থাকতে পারি না।", [
		"very",
		"enough",
		"too",
		"much"
	], "too", "Too hot = cannot stay.", "Too + to।"),
	q(36, "much-very-too", "Replace the error: His health is too good.", "ভুল শ바로।", [
		"His health is very good.",
		"His health is much good.",
		"His health is enough good.",
		"His health is too much good."
	], "His health is very good.", "No excess is meant.", "সীমা ছাড়ানো নেই — very।"),
	q(37, "much-very-too", "I shall be only too glad to have you here. This means:", "অর্থ কী?", [
		"I shall not be glad",
		"I shall be very glad",
		"I shall be too busy",
		"I shall be barely glad"
	], "I shall be very glad", "Only too glad = very glad, not the reverse.", "Only too glad = খুব খুশি।"),
	q(38, "much-very-too", "Five rupees is ___ for this. (the proper price)", "দাম ঠিক।", [
		"too high",
		"enough",
		"very",
		"much"
	], "enough", "Enough = as high as it should be.", "Enough = যথাযথ।"),
	q(39, "much-very-too", "___ rumours were spread and there was ___ bloodshed.", "গুজব ও রক্তপাত।", [
		"Much / many",
		"Many / much",
		"Many / many",
		"Much / much"
	], "Many / much", "Rumours countable; bloodshed uncountable.", "Rumours = many; bloodshed = much।"),
	q(40, "much-very-too", "It is a ___ interesting book. I was ___ interested in him.", "মজার / আগ্রহী।", [
		"much / very",
		"very / much",
		"too / very",
		"very / too"
	], "very / much", "Interesting (present part.) very; interested (past part.) much.", "interesting-এ very।"),
	q(41, "any-some-each", "He did not want ___ help.", "সাহায্য চায়নি।", [
		"some",
		"any",
		"every",
		"each"
	], "any", "Any in negatives.", "নেতিবাচকে any।"),
	q(42, "any-some-each", "Will you kindly give me ___ milk?", "অনুরোধ।", [
		"any",
		"some",
		"every",
		"few"
	], "some", "Requests disguised as questions take some.", "অনুরোধে some।"),
	q(43, "any-some-each", "Is there ___ man there? (genuine question)", "সত্যিই কেউ আছে?", [
		"some",
		"any",
		"every",
		"each"
	], "any", "Prefer any in real questions.", "প্রশ্নে any।"),
	q(44, "any-some-each", "You may follow ___ course you like.", "যেকোনো পথ।", [
		"some",
		"any",
		"every",
		"few"
	], "any", "Any as indefinite demonstrative.", "অনির্দিষ্ট any।"),
	q(45, "any-some-each", "Which dress would suit you? ___ would do. (a thing)", "যেকোনো একটি পোশাক।", [
		"Anyone",
		"Any one",
		"Everyone",
		"Someone"
	], "Any one", "Two words for things or numerical one.", "জিনিসে any one।"),
	q(46, "any-some-each", "___ who wants to enter may send his name.", "যে কেউ।", [
		"Any one",
		"Anyone",
		"Someone",
		"Each one"
	], "Anyone", "Anyone (one word) refers to persons.", "মানুষে anyone।"),
	q(47, "any-some-each", "I have many ___ book of this kind.", "এই ধরনের অনেক বই (many a)।", [
		"a",
		"a books",
		"books",
		"the books"
	], "a", "Many a + singular noun.", "Many a book।"),
	q(48, "any-some-each", "Many a man ___ to get rich quickly.", "ক্রিয়া বাছুন।", [
		"want",
		"wants",
		"are wanting",
		"have wanted"
	], "wants", "Many a takes a singular verb.", "একবচন ক্রিয়া।"),
	q(49, "any-some-each", "I have ___ books of this kind. (plural)", "অনেক বই।", [
		"many a",
		"a great many",
		"much",
		"every"
	], "a great many", "A great many + plural noun.", "A great many books।"),
	q(50, "any-some-each", "I gave a book to ___ of the two boys.", "দুইজনের প্রত্যেক।", [
		"every",
		"each",
		"all",
		"both every"
	], "each", "Each of two; every is more than two only.", "দুইয়ে each।"),
	q(51, "any-some-each", "I gave a book to ___ one of the five boys.", "পাঁচজন।", [
		"each",
		"every",
		"either",
		"neither"
	], "every", "Every for more than two (each is also possible, but the drill contrast is every).", "দুইয়ের বেশি — every।"),
	q(52, "any-some-each", "___ of the two books is useful.", "দুটির প্রত্যেকটি।", [
		"Every",
		"Each",
		"All",
		"Anyones"
	], "Each", "Cannot use every of two.", "দুইয়ে every নয়।"),
	q(53, "order-degree", "He came ___ than my brother. (time)", "সময় পরে এল।", [
		"latter",
		"later",
		"latest",
		"last"
	], "later", "Later = time.", "Later = সময়।"),
	q(54, "order-degree", "I want the former, not the ___.", "দ্বিতীয়টি নয়।", [
		"later",
		"latter",
		"latest",
		"last"
	], "latter", "Latter = the second of two (order).", "Latter = ক্রম।"),
	q(55, "order-degree", "What is the ___ news?", "সবচেয়ে নতুন খবর।", [
		"last",
		"latest",
		"latter",
		"later"
	], "latest", "Latest = most recent in time.", "Latest = সময়ের নতুনতম।"),
	q(56, "order-degree", "He is the ___ boy in the class. (order)", "ক্রমে শেষ।", [
		"latest",
		"last",
		"latter",
		"later"
	], "last", "Last = order.", "Last = ক্রম।"),
	q(57, "order-degree", "I have made ___ progress. (additional)", "আরও অগ্রগতি।", [
		"farther",
		"further",
		"farthest",
		"furthest"
	], "further", "Further is preferred except for distinct distance.", "অতিরিক্ত = further।"),
	q(58, "order-degree", "He went the ___ of all. (distance)", "সবচেয়ে দূরে।", [
		"further",
		"farther",
		"latest",
		"latter"
	], "farther", "Farther when distance is distinct.", "দূরত্বে farther।"),
	q(59, "order-degree", "Thus far and no ___.", "এতদূর, তার বেশি নয়।", [
		"further",
		"farther",
		"later",
		"latter"
	], "farther", "Physical limit of distance.", "দূরত্বের সীমা।"),
	q(60, "order-degree", "He stood ___ in the examination, and is the ___ player of the team.", "অবস্থান ও খ্যাতি।", [
		"foremost / first",
		"first / foremost",
		"next / nearest",
		"last / latest"
	], "first / foremost", "First = order; foremost = most conspicuous.", "First = ক্রম; foremost = বিশিষ্ট।"),
	q(61, "order-degree", "We ran for shelter to the ___ house.", "সবচেয়ে কাছের বাড়ি।", [
		"next",
		"nearest",
		"later",
		"latter"
	], "nearest", "Nearest = distance.", "Nearest = দূরত্ব।"),
	q(62, "order-degree", "The chairman took up the ___ item.", "পরবর্তী আইটেম।", [
		"nearest",
		"next",
		"later",
		"latter"
	], "next", "Next = order in a list.", "Next = ক্রম।"),
	q(63, "order-degree", "He is ___ than I, and he is my ___ brother.", "বয়স ও পরিবার।", [
		"elder / older",
		"older / elder",
		"oldest / eldest",
		"eldest / older"
	], "older / elder", "Older general; elder same family.", "Older সাধারণ; elder পরিবার।"),
	q(64, "order-degree", "This tree is ___ than that.", "গাছের বয়স।", [
		"elder",
		"older",
		"eldest",
		"oldest"
	], "older", "Elder is not used of trees.", "গাছে elder নয়।"),
	q(65, "order-degree", "She is my ___ sister.", "পরিবারের জ্যেষ্ঠা।", [
		"oldest",
		"eldest",
		"latter",
		"latest"
	], "eldest", "Eldest for family.", "Eldest = পরিবার।"),
	q(66, "order-degree", "Draw a tangent to the ___ circle.", "বাইরের বৃত্ত।", [
		"utter",
		"outer",
		"uttermost",
		"out"
	], "outer", "Outer = position.", "Outer = অবস্থান।"),
	q(67, "order-degree", "This will bring on ___ ruin.", "সম্পূর্ণ ধ্বংস।", [
		"outer",
		"utter",
		"uttering",
		"out"
	], "utter", "Utter = complete degree.", "Utter = সম্পূর্ণ।"),
	q(68, "adverb-pairs", "He came ___. (after the appointed time)", "বিলম্বে।", [
		"lately",
		"late",
		"later",
		"latest"
	], "late", "Late = after time.", "Late = বিলম্বে।"),
	q(69, "adverb-pairs", "He has ___ purchased a plot of land.", "সম্প্রতি কিনেছে।", [
		"late",
		"lately",
		"later",
		"latest"
	], "lately", "Lately = recently.", "Lately = সম্প্রতি।"),
	q(70, "adverb-pairs", "He worked so ___ that his health broke down.", "কঠোর পরিশ্রম।", [
		"hardly",
		"hard",
		"harder",
		"hardly ever"
	], "hard", "Hard = diligently. Hardly would mean scarcely.", "Hard = কঠোরভাবে।"),
	q(71, "adverb-pairs", "I can ___ bear the strain.", "কদাচিৎ সহ্য হয়।", [
		"hard",
		"hardly",
		"hardy",
		"harder"
	], "hardly", "Hardly = scarcely.", "Hardly = কদাচিৎ।"),
	q(72, "adverb-pairs", "He will come here ___. (soon)", "শীঘ্রই।", [
		"in short",
		"shortly",
		"short",
		"shortness"
	], "shortly", "Modern shortly = soon.", "Shortly = শীঘ্রই।"),
	q(73, "adverb-pairs", "Give ___ an account of the excursion.", "সংক্ষেপে বিবরণ।", [
		"shortly",
		"in short",
		"short",
		"shortest"
	], "in short", "In short = briefly (the textbook drill).", "In short = সংক্ষেপে।"),
	q(74, "adverb-pairs", "He sits ___ me in the class.", "পাশে বসে।", [
		"besides",
		"beside",
		"beside of",
		"besides of"
	], "beside", "Beside = next to.", "Beside = পাশে।"),
	q(75, "adverb-pairs", "___ money, he gave me a house also.", "টাকার অতিরিক্ত।", [
		"Beside",
		"Besides",
		"Beside of",
		"Except"
	], "Besides", "Besides = in addition to.", "Besides = অতিরিক্ত।"),
	q(76, "adverb-pairs", "Your remark is ___ the point.", "অপ্রাসঙ্গিক।", [
		"besides",
		"beside",
		"besides of",
		"except"
	], "beside", "Beside the point = wide of.", "Beside the point।"),
	q(77, "adverb-pairs", "I have no work on hand ___. (now)", "এখন কাজ নেই।", [
		"presently",
		"at present",
		"at last",
		"after all"
	], "at present", "At present = now. Presently = soon in Indian exam English.", "At present = বর্তমানে।"),
	q(78, "adverb-pairs", "He will attend to you ___. (very soon)", "শীঘ্রই দেখবে।", [
		"at present",
		"presently",
		"after all",
		"at last"
	], "presently", "Presently = soon.", "Presently = শীঘ্রই।"),
	q(79, "adverb-pairs", "Your enemy is ___ an honest person.", "যা-ই বলুন, তবু সৎ।", [
		"at last",
		"finally",
		"after all",
		"at least"
	], "after all", "After all = in spite of what is said against him.", "After all ≠ finally।"),
	q(80, "adverb-pairs", "He served thirty years and ___ retired on a pension.", "স্বাভাবিক পরিণতি।", [
		"after all",
		"finally / at last",
		"at least",
		"at present"
	], "finally / at last", "After all is wrong for a natural consequence.", "স্বাভাবিক শেষ = finally/at last।"),
	q(81, "adverb-pairs", "This will cost me ___ fifty rupees.", "কম হলেও পঞ্চাশ।", [
		"at last",
		"at least",
		"at length",
		"after all"
	], "at least", "At least = minimum estimate.", "At least = অন্তত।"),
	q(82, "adverb-pairs", "I saw him two months ___.", "এখন থেকে দুই মাস আগে।", [
		"before",
		"ago",
		"since ago",
		"after"
	], "ago", "Ago measures back from now.", "Ago = এখন থেকে পেছনে।"),
	q(83, "adverb-pairs", "I had seen him two months ___.", "সেই অতীতের দুই মাস আগে।", [
		"ago",
		"before",
		"since",
		"for"
	], "before", "Before from a past reference point.", "Before = অতীত বিন্দু থেকে।"),
	q(84, "adverb-pairs", "When I ___ him, I shall give him the message.", "দেখলেই দেব।", [
		"shall see",
		"will see",
		"see",
		"saw"
	], "see", "Before/when/after take present even if the main verb is future.", "ভবিষ্যতের আগেও present।"),
	q(85, "adverb-pairs", "All boys, not ___ Ram, went there. (including Ram)", "রামকেও ধরে।", [
		"except",
		"excepting",
		"except for",
		"except that"
	], "excepting", "Not excepting = including.", "Not excepting = including।"),
	q(86, "adverb-pairs", "This essay is fairly good ___ some careless mistakes.", "ভুল বাদ দিলে ভালো।", [
		"except that",
		"excepting",
		"except for",
		"excepting that"
	], "except for", "Except for = exception to a general condition.", "Except for।"),
	q(87, "adverb-pairs", "I knew nothing except ___ he was likely to see Mr Roy.", "এই তথ্য ছাড়া।", [
		"for",
		"that",
		"ing",
		"to"
	], "that", "Except that + clause.", "Except that + clause।"),
	q(88, "prepositions-place", "He was digging the earth ___ a spade, when he was bitten ___ a snake.", "যন্ত্র ও কর্তা।", [
		"by / with",
		"with / by",
		"with / with",
		"by / by"
	], "with / by", "Instrument with; agent by.", "Spade = with; snake = by।"),
	q(89, "prepositions-place", "The planet may be seen ___ the naked eye.", "খালি চোখে।", [
		"by",
		"with",
		"from",
		"at"
	], "with", "The eye is the instrument.", "চোখ = যন্ত্র, with।"),
	q(90, "prepositions-place", "He was struck ___ lightning.", "বজ্রপাত।", [
		"with",
		"by",
		"from",
		"of"
	], "by", "Lightning is treated as the agent.", "Lightning = by।"),
	q(91, "prepositions-place", "His throat was cut ___ a razor ___ the murderer.", "যন্ত্র ও হত্যাকারী।", [
		"by / with",
		"with / by",
		"by / by",
		"with / with"
	], "with / by", "Razor instrument; murderer agent.", "Razor with; murderer by।"),
	q(92, "prepositions-place", "He died ___ his own hand.", "আত্মঘাত।", [
		"with",
		"by",
		"from",
		"of"
	], "by", "Idiom: die by one's own hand.", "By his own hand।"),
	q(93, "prepositions-place", "The prize is to be divided ___ these two boys.", "দুইজন।", [
		"among",
		"between",
		"in",
		"within"
	], "between", "Two: between.", "দুইয়ে between।"),
	q(94, "prepositions-place", "The property will be divided ___ four brothers.", "চার ভাই।", [
		"between",
		"among",
		"with",
		"by"
	], "among", "More than two: among.", "চারে among।"),
	q(95, "prepositions-place", "The doll is made ___ plastic. Threads are made ___ cotton.", "উপকরণ।", [
		"from / of",
		"of / from",
		"of / of",
		"from / from"
	], "of / from", "Plastic remains; cotton is transformed.", "অক্ষত of; রূপান্তর from।"),
	q(96, "prepositions-place", "Wine is made ___ grapes. The table is made ___ wood.", "আঙ্গুর ও কাঠ।", [
		"of / from",
		"from / of",
		"of / of",
		"from / from"
	], "from / of", "Grapes lose composition; wood remains.", "From grapes; of wood।"),
	q(97, "prepositions-place", "He lives ___ Jangipur ___ the district of Murshidabad.", "ছোট স্থান ও জেলা।", [
		"in / at",
		"at / in",
		"at / at",
		"in / in"
	], "at / in", "Village at; district in.", "ছোট at, বড় in।"),
	q(98, "prepositions-place", "He lives ___ a flat ___ 12, Chowringhee Road.", "ফ্ল্যাট ও নির্দিষ্ট ঠিকানা।", [
		"at / in",
		"in / at",
		"in / in",
		"at / at"
	], "in / at", "Kind of dwelling in; specific address at.", "ধরন in; ঠিকানা at।"),
	q(99, "prepositions-place", "The girls ran ___ the hall. There was nobody ___ the room.", "গতি ও স্থিতি।", [
		"in / into",
		"into / in",
		"in / in",
		"into / into"
	], "into / in", "Motion into; rest in.", "গতি into; স্থিতি in।"),
	q(100, "prepositions-place", "The ice melted ___ water.", "রূপান্তর।", [
		"in",
		"into",
		"to in",
		"at"
	], "into", "Change of state takes into.", "রূপান্তর into।"),
	q(101, "prepositions-place", "A treaty ___ six nations was signed.", "পারস্পরিক চুক্তি।", [
		"among",
		"between",
		"in",
		"within"
	], "between", "Mutual relation: between may take more than two.", "পারস্পরিক সম্পর্কে between।"),
	q(102, "prepositions-place", "He is employed ___ the Accounts Department ___ the G.P.O.", "বিভাগ ও নির্দিষ্ট অফিস।", [
		"at / in",
		"in / at",
		"in / in",
		"at / at"
	], "in / at", "Department in; specific building at.", "বিভাগ in; GPO at।"),
	q(103, "prepositions-time", "Wait ___ an hour.", "এক ঘণ্টা ধরে।", [
		"since",
		"for",
		"from",
		"at"
	], "for", "For = duration.", "বিস্তার for।"),
	q(104, "prepositions-time", "He has been doing it ___ 1920.", "১৯২০ থেকে এখন।", [
		"for",
		"since",
		"ago",
		"in"
	], "since", "Past point + present perfect = since.", "অতীত বিন্দু + perfect = since।"),
	q(105, "prepositions-time", "He has been doing it ___ his infancy.", "শৈশব থেকে।", [
		"for",
		"ago",
		"from",
		"in"
	], "from", "From marks a starting point in any tense; infancy is the classic ‘from’ drill.", "শৈশব = from (পাঠ্য ড্রিল)।"),
	q(106, "prepositions-time", "He has been living here ___ a long time.", "দীর্ঘকাল।", [
		"since",
		"from",
		"for",
		"ago"
	], "for", "A long time is duration.", "বিস্তার for।"),
	q(107, "prepositions-time", "I have been ill ___ Monday last.", "গত সোমবার থেকে।", [
		"for",
		"since",
		"from",
		"ago"
	], "since", "Monday last is a past point.", "বিন্দু since।"),
	q(108, "prepositions-time", "He begins English ___ today and will begin French ___ tomorrow.", "আজ ও আগামীকাল থেকে।", [
		"since / since",
		"from / from",
		"for / for",
		"ago / ago"
	], "from / from", "From works with present and future points.", "From সব tense-এর বিন্দুতে।"),
	q(109, "prepositions-time", "It is five years ___ he came here last.", "পাঁচ বছর হয়ে গেল।", [
		"ago since",
		"ago that",
		"since",
		"for"
	], "since", "It is + period + since + past indefinite.", "It is … since।"),
	q(110, "prepositions-time", "It was ten years ago ___ he died.", "দশ বছর আগে মারা যায়।", [
		"since",
		"that",
		"for",
		"from"
	], "that", "Ago is followed by that, never since.", "Ago that, ago since নয়।"),
	q(111, "prepositions-time", "Pick the incorrect sentence.", "ভুল বাক্য।", [
		"He last came here five years ago.",
		"It is five years since he came here last.",
		"It is five years ago since he came here.",
		"He died ten years ago."
	], "It is five years ago since he came here.", "Ago since is tautological.", "Ago since নিষিদ্ধ।"),
	q(112, "prepositions-time", "As an adverb meaning ‘from then till now’, since follows:", "কোন tense?", [
		"past indefinite only",
		"present perfect or past perfect",
		"future only",
		"present continuous"
	], "present perfect or past perfect", "I have known him ever since.", "Perfect-এর সাথে ever since।"),
	q(113, "prepositions-time", "He died long since. Here since means:", "এখানে since =", [
		"for a long time",
		"ago",
		"because",
		"from today"
	], "ago", "With past indefinite, adverb since = ago. Modern writers prefer ago.", "Past indefinite-এ since = ago।"),
	q(114, "prepositions-time", "The moon will not rise ___ five days.", "পাঁচ দিন উঠবে না।", [
		"before",
		"for",
		"in",
		"after"
	], "for", "For in negatives = future duration.", "নেতিবাচক ভবিষ্যৎ বিস্তার = for।"),
	q(115, "prepositions-time", "The moon will not rise ___ midnight.", "মধ্যরাতের আগে নয়।", [
		"for",
		"before",
		"in",
		"since"
	], "before", "Before = a point of time.", "বিন্দু before।"),
	q(116, "prepositions-time", "He will come ___ a few days.", "কয়েক দিন পরে আসবে।", [
		"after",
		"in",
		"since",
		"ago"
	], "in", "In = future space of time. After a few days is wrong for the future.", "ভবিষ্যৎ বিস্তার = in।"),
	q(117, "prepositions-time", "He died ___ a few days.", "কয়েক দিন পরে মারা গেল।", [
		"in",
		"after",
		"within",
		"for"
	], "after", "After = past space of time.", "অতীত বিস্তার = after।"),
	q(118, "prepositions-time", "I shall go ___ a week. (= after the week has ended)", "সপ্তাহ শেষে।", [
		"within",
		"in",
		"for",
		"since"
	], "in", "In = at the end of.", "In = শেষে।"),
	q(119, "prepositions-time", "I shall go ___ a week. (= before the week has ended)", "সপ্তাহ শেষ হওয়ার আগে।", [
		"in",
		"within",
		"after",
		"since"
	], "within", "Within = some time before the end.", "Within = মধ্যে।"),
	q(120, "prepositions-time", "You must be back ___ 5 o’clock.", "পাঁচটার পরে নয়।", [
		"at only",
		"by",
		"since",
		"for"
	], "by", "By = not later than; may be earlier.", "By = শেষ সময়সীমা।"),
	q(121, "prepositions-time", "He came ___ noon.", "ঠিক দুপুরে।", [
		"in",
		"by",
		"at",
		"within"
	], "at", "At = definite point.", "At noon।"),
	q(122, "prepositions-time", "We reached the place ___ the same time. (= the same clock hour)", "একই ঘটিকা।", [
		"in",
		"at",
		"within",
		"by"
	], "at", "At the same time = same hour.", "At = ঘড়ি।"),
	q(123, "prepositions-time", "We reached the place ___ the same time. (= took equally long, say 5 hours)", "একই সময় লেগেছে।", [
		"at",
		"in",
		"by",
		"since"
	], "in", "In the same time = same duration.", "In = স্থিতিকাল।"),
	q(124, "prepositions-time", "Come here ___ 5 o’clock.", "পাঁচটায় এসো।", [
		"in",
		"for",
		"at",
		"since"
	], "at", "Point of time: at.", "At 5 o’clock।"),
	q(125, "prepositions-time", "The school shall not open ___ a month more.", "আর এক মাস খুলবে না।", [
		"in",
		"for",
		"after",
		"at"
	], "for", "Negative future duration: for.", "নেতিবাচক for।"),
	q(126, "prepositions-time", "Wait here until I ___.", "যতক্ষণ না আসি।", [
		"do not come",
		"come",
		"shall not come",
		"will come"
	], "come", "Until already negative; do not add not.", "Until-এর সাথে not নয়।"),
	q(127, "prepositions-time", "___ you work hard, you will fail.", "যদি না কঠোর পরিশ্রম করো।", [
		"Unless",
		"Unless you do not",
		"Until not",
		"If unless"
	], "Unless", "Unless = if not. Unless you do not is a double negative.", "Unless you work hard।"),
	q(128, "sticky-phrases", "All had left ___ me. (except)", "আমাকে বাদে সবাই।", [
		"but",
		"and",
		"as",
		"so"
	], "but", "But as preposition = except; object me.", "But = except, me।"),
	q(129, "sticky-phrases", "He is ___ a child.", "কেবল শিশু।", [
		"but",
		"as",
		"since",
		"for"
	], "but", "Adverb but = only.", "But = only।"),
	q(130, "sticky-phrases", "There is none ___ wishes to be happy.", "যে না চায় এমন কেউ নেই।", [
		"who",
		"but",
		"as",
		"that not who"
	], "but", "Relative but = who not.", "But = who not।"),
	q(131, "sticky-phrases", "He worked as best ___ he could.", "যথাসাধ্য।", [
		"as",
		"— (no as)",
		"than",
		"so"
	], "— (no as)", "Not as best as: best is already superlative.", "As best as ভুল।"),
	q(132, "sticky-phrases", "Choose the correct sentence.", "সঠিকটি।", [
		"I could not come due to illness.",
		"Due to illness I could not come.",
		"His illness was due to exposure to cold.",
		"Due to he was ill."
	], "His illness was due to exposure to cold.", "Due must qualify a noun (illness).", "Due noun-কে qualify করে।"),
	q(133, "sticky-phrases", "I doubt ___ Easter will be fine.", "সন্দেহ — ইতিবাচক।", [
		"that",
		"whether",
		"as to that",
		"about whether"
	], "whether", "Positive doubt takes whether, not that.", "ইতিবাচক doubt + whether।"),
	q(134, "sticky-phrases", "I do not doubt ___ he is honest.", "সন্দেহ নেই।", [
		"whether",
		"that",
		"if whether",
		"as to"
	], "that", "Negative/interrogative doubt takes that.", "নেতিবাচক doubt + that।"),
	q(135, "sticky-phrases", "I have no friend other ___ you.", "তোমাকে ছাড়া।", [
		"but",
		"than",
		"from",
		"to"
	], "than", "Other is generally followed by than.", "Other than।"),
	q(136, "sticky-phrases", "Which is incorrect in ordinary English?", "সাধারণ ইংরেজিতে ভুল।", [
		"I wrote you a letter.",
		"I wrote a letter.",
		"I wrote to you.",
		"I wrote you."
	], "I wrote you.", "Without a direct object, use to. ‘I wrote you’ is only business English.", "Write you — ব্যবসায়িক ছাড়া নয়।"),
	q(137, "sticky-phrases", "I prevented him ___ troubling you.", "বাধা দিলাম।", [
		"to",
		"from",
		"for",
		"of"
	], "from", "Prevent + noun + from + gerund.", "Prevent from doing।"),
	q(138, "sticky-phrases", "I shall try to prevent ___ coming.", "আসা ঠেকাব।", [
		"him",
		"his",
		"he",
		"he's"
	], "his", "Grammar demands possessive before the gerund.", "Prevent his coming।"),
	q(139, "sticky-phrases", "That was worth doing. Adding while would be:", "while যোগ করলে?", [
		"necessary",
		"superfluous",
		"more literary",
		"required by Fowler"
	], "superfluous", "Doing is already the object of worth.", "Doing-ই object — while বাড়তি।"),
	q(140, "sticky-phrases", "It is ___ doing the extra work.", "dummy it।", [
		"worth",
		"worth while",
		"worthy",
		"worth of"
	], "worth while", "Dummy it; the gerund is the real subject, so while is the object of worth.", "It dummy হলে while চাই।"),
	q(141, "sticky-phrases", "Admission by tickets only, ___ only ticket-holders may enter.", "অর্থাৎ।", [
		"e.g.",
		"i.e.",
		"viz.",
		"etc."
	], "i.e.", "i.e. restates more clearly; e.g. gives examples; viz. names them.", "i.e. = that is।"),
	q(142, "sticky-phrases", "The nations are interdependent, ___ England depends on India for raw materials.", "উদাহরণ।", [
		"i.e.",
		"e.g.",
		"viz.",
		"n.b."
	], "e.g.", "e.g. = for instance.", "e.g. = উদাহরণ।"),
	q(143, "sticky-phrases", "There were only three men present, ___ Ramesh and his two brothers.", "অর্থাৎ নাম করে।", [
		"e.g.",
		"i.e.",
		"viz.",
		"etc."
	], "viz.", "viz. = namely.", "viz. = namely।"),
	q(144, "sticky-phrases", "I shall go there ___ the weather is fine.", "শর্ত আমার।", [
		"provided",
		"providing that always",
		"due to",
		"excepting"
	], "provided", "Provided introduces a stipulation made by the speaker.", "Provided = শর্ত।"),
	q(145, "sticky-phrases", "2,512 in words:", "কথায়।", [
		"two thousand five hundred twelve",
		"two thousand, five hundred and twelve",
		"two thousands five hundred and twelve",
		"twenty five hundred twelve"
	], "two thousand, five hundred and twelve", "And is placed before the last word.", "শেষ শব্দের আগে and।"),
	q(146, "sticky-phrases", "Wake me at 7.10. Which is wrong?", "কোনটি ভুল?", [
		"seven ten",
		"ten past seven",
		"ten past seven o’clock",
		"7.10"
	], "ten past seven o’clock", "O’clock is used only for the whole hour, never with a.m./p.m.", "O’clock শুধু পূর্ণ ঘণ্টায়।"),
	q(147, "sticky-phrases", "He gets up at 4 o’clock ___.", "সকাল চারটে।", [
		"a.m.",
		"in the morning",
		"p.m.",
		"o’clock a.m."
	], "in the morning", "Do not combine o’clock with a.m./p.m.", "O’clock + a.m. নয়।"),
	q(148, "sticky-phrases", "Prefer the literary form:", "সাহিত্যিক রূপ।", [
		"one and a half feet",
		"a foot and a half",
		"one and half foot",
		"one and a halfs feet"
	], "a foot and a half", "MEU prefers a foot and a half in literary contexts.", "A foot and a half।"),
	q(149, "sticky-phrases", "One and a half lemons ___ enough.", "ক্রিয়া।", [
		"were",
		"was",
		"are",
		"have been"
	], "was", "After one and a half: plural noun, singular verb.", "Plural noun + singular verb।"),
	q(150, "parts-of-speech", "In “But me no buts,” the two uses of but are:", "দুই পদ।", [
		"preposition and conjunction",
		"verb and noun",
		"adverb and relative",
		"adjective and verb"
	], "verb and noun", "First but is a verb; second is a noun.", "প্রথম ক্রিয়া, দ্বিতীয় বিশেষ্য।")
];
if (questions.length !== 150) throw new Error(`Expected 150 questions, got ${questions.length}`);
//#endregion
export { questions as t };
