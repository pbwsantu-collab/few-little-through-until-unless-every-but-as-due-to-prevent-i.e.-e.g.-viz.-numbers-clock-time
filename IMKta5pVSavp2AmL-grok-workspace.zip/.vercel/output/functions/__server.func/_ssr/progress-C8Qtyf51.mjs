import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/progress-C8Qtyf51.js
var memory = { map: {} };
var useProgress = create()(persist((set, get) => ({
	completedLessons: [],
	quiz: {},
	bookmarks: [],
	markLesson: (id) => set({ completedLessons: get().completedLessons.includes(id) ? get().completedLessons : [...get().completedLessons, id] }),
	saveAnswer: (id, picked, correct) => set({ quiz: {
		...get().quiz,
		[id]: {
			picked,
			correct
		}
	} }),
	resetQuiz: () => set({ quiz: {} }),
	toggleBookmark: (id) => {
		set({ bookmarks: get().bookmarks.includes(id) ? get().bookmarks.filter((x) => x !== id) : [...get().bookmarks, id] });
	}
}), {
	name: "shabdabhed-progress",
	storage: createJSONStorage(() => typeof window === "undefined" ? {
		getItem: (k) => memory.map[k] ?? null,
		setItem: (k, v) => {
			memory.map[k] = v;
		},
		removeItem: (k) => {
			delete memory.map[k];
		}
	} : localStorage)
}));
//#endregion
export { useProgress as t };
