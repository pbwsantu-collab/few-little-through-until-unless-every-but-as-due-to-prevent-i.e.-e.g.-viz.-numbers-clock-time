import { b as require_jsx_runtime, v as Link, z as notFound } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-DKzWdXd5.mjs";
import { n as chapters, t as chapterById } from "./lessons-DRFcRenz.mjs";
import { t as useProgress } from "./progress-C8Qtyf51.mjs";
import { t as RuleBlock } from "./rule-block-DsX2vrq5.mjs";
import { t as Button } from "./button-Bh4bdQ9H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lessons._id-DtcPTIV8.js
var import_jsx_runtime = require_jsx_runtime();
function LessonPage() {
	const { id } = Route.useParams();
	const chapter = chapterById[id];
	if (!chapter) throw notFound();
	const mark = useProgress((s) => s.markLesson);
	const done = useProgress((s) => s.completedLessons.includes(id));
	const idx = chapters.findIndex((c) => c.id === id);
	const prev = chapters[idx - 1];
	const next = chapters[idx + 1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs font-medium text-primary",
			children: [
				"অধ্যায় ",
				chapter.index,
				" / ",
				chapters.length,
				" · ",
				chapter.article,
				" · ~",
				chapter.minutes,
				" মিনিট"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display mt-1 text-3xl font-semibold",
			children: chapter.titleEn
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "bn mt-1 text-lg text-muted",
			children: chapter.titleBn
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "bn mt-4 max-w-2xl leading-relaxed",
			children: chapter.summaryBn
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 space-y-5",
			children: chapter.sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleBlock, { section: s }, s.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 flex flex-wrap items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				onClick: () => mark(id),
				children: done ? "পড়া হিসেবে চিহ্নিত" : "এই পাঠ শেষ করুন"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/practice",
				search: { chapter: id },
				className: "text-sm text-primary underline-offset-2 hover:underline",
				children: "এই অধ্যায়ের প্রশ্ন"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 flex justify-between gap-3 border-t border-border pt-6",
			children: [prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/lessons/$id",
				params: { id: prev.id },
				className: "text-sm text-muted",
				children: ["← ", prev.titleBn]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/lessons/$id",
				params: { id: next.id },
				className: "text-sm text-primary",
				children: [next.titleBn, " →"]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/practice",
				className: "text-sm text-primary",
				children: "১৫০ প্রশ্নে যান →"
			})]
		})
	] });
}
//#endregion
export { LessonPage as component };
