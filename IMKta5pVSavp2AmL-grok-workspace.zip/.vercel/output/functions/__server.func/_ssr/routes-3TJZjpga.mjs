import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as WifiOff, s as ChevronRight } from "../_libs/lucide-react.mjs";
import { n as chapters } from "./lessons-DRFcRenz.mjs";
import { t as useProgress } from "./progress-C8Qtyf51.mjs";
import { t as questions } from "./questions-CGg4OiG9.mjs";
import { t as posWords } from "./pos-words-D_4kdBhZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-3TJZjpga.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const completed = useProgress((s) => s.completedLessons);
	const quiz = useProgress((s) => s.quiz);
	const answered = Object.keys(quiz).length;
	const correct = Object.values(quiz).filter((x) => x.correct).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-xl border border-border bg-surface p-6 shadow-card md:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-primary uppercase",
					children: "§308–347 · Textbook companion"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-2 text-3xl font-semibold tracking-tight text-ink md:text-4xl",
					children: "শব্দভেদ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "bn mt-3 max-w-2xl text-lg leading-relaxed text-ink",
					children: "Higher English Grammar-এর শব্দ-ব্যবহার অধ্যায়গুলো ক্রমবদ্ধ পাঠে সাজানো। প্রতিটি নিয়মের বাংলা যুক্তি, ইংরেজি উদাহরণ, ব্যতিক্রম, আর একশো পঞ্চাশটি প্রশ্ন — সব অ্যাপেই আছে।"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
					children: "Few/little through until/unless, sticky phrases (but, due to, prevent, i.e.), and every word in §347 used as different parts of speech."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-wrap gap-2 text-xs text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-full bg-ok-soft px-3 py-1 text-ok",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiOff, { className: "size-3.5" }), " একবার লোড হলে অফলাইনে চলে"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-bg px-3 py-1",
							children: [chapters.length, " অধ্যায়"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-bg px-3 py-1",
							children: [questions.length, " প্রশ্ন"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-bg px-3 py-1",
							children: [posWords.length, " শব্দ · নানা পদ"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/lessons/$id",
						params: { id: chapters[0].id },
						className: "inline-flex h-11 items-center rounded-md bg-primary px-4 text-sm text-primary-fg",
						children: "প্রথম পাঠ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/practice",
						className: "inline-flex h-11 items-center rounded-md border border-border-strong bg-surface px-4 text-sm",
						children: "১৫০ প্রশ্ন"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "পাঠ শেষ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display mt-1 text-2xl tabular-nums",
					children: [
						completed.length,
						"/",
						chapters.length
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "সঠিক উত্তর"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display mt-1 text-2xl tabular-nums",
					children: [
						correct,
						"/",
						answered || 0
					]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display mt-10 text-xl font-semibold",
			children: "পাঠক্রম"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "bn mt-1 text-sm text-muted",
			children: "বইয়ের পাতার জগাখিচুড়ি নয় — ধারণা গড়ে তোলার ক্রম।"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-4 space-y-2",
			children: chapters.map((ch) => {
				const done = completed.includes(ch.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/lessons/$id",
					params: { id: ch.id },
					className: "flex items-start justify-between gap-3 rounded-lg border border-border bg-surface p-4 hover:border-border-strong",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-primary",
							children: [
								"অধ্যায় ",
								ch.index,
								" · ",
								ch.article,
								done ? " · পড়া হয়েছে" : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display mt-0.5 text-lg font-semibold",
							children: ch.titleEn
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "bn text-sm text-muted",
							children: ch.titleBn
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "bn mt-2 text-sm leading-relaxed text-ink",
							children: ch.summaryBn
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "mt-1 size-5 shrink-0 text-subtle" })]
				}) }, ch.id);
			})
		})
	] });
}
//#endregion
export { Home as component };
