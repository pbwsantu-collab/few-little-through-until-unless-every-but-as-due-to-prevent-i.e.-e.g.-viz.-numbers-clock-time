import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Bookmark } from "../_libs/lucide-react.mjs";
import { i as cn } from "./router-DKzWdXd5.mjs";
import { t as useProgress } from "./progress-C8Qtyf51.mjs";
import { t as posWords } from "./pos-words-D_4kdBhZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/words-3p6x8vCd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Words() {
	const [q, setQ] = (0, import_react.useState)("");
	const [active, setActive] = (0, import_react.useState)(posWords[0].word);
	const bookmarks = useProgress((s) => s.bookmarks);
	const toggle = useProgress((s) => s.toggleBookmark);
	const filtered = (0, import_react.useMemo)(() => {
		const s = q.trim().toLowerCase();
		if (!s) return posWords;
		return posWords.filter((w) => w.word.toLowerCase().includes(s));
	}, [q]);
	const word = posWords.find((w) => w.word === active) ?? filtered[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-semibold",
			children: "একই শব্দ, নানা পদ"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "bn mt-2 text-muted",
			children: "§347 — About থেকে Wrong। বাক্যে কাজ দেখে পদ চিনুন।"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: q,
			onChange: (e) => setQ(e.target.value),
			placeholder: "শব্দ খুঁজুন",
			className: "mt-4 h-11 w-full rounded-md border border-border bg-surface px-3 text-sm"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 flex flex-wrap gap-1.5",
			children: filtered.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setActive(w.word),
				className: cn("h-9 rounded-md px-3 text-sm", active === w.word ? "bg-primary text-primary-fg" : "border border-border bg-surface"),
				children: w.word
			}, w.word))
		}),
		word ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 rounded-xl border border-border bg-surface p-5 shadow-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-semibold",
						children: word.word
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => toggle(word.word),
						className: "rounded-md p-2 hover:bg-bg",
						"aria-label": "bookmark",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: cn("size-5", bookmarks.includes(word.word) ? "fill-primary text-primary" : "text-muted") })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-3",
					children: word.uses.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-md bg-bg p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs font-medium text-primary",
								children: [
									u.pos,
									" · ",
									u.posBn
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1",
								children: u.example
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "bn mt-0.5 text-sm text-muted",
								children: u.exampleBn
							})
						]
					}, u.pos + u.example))
				}),
				word.notes?.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "bn mt-4 rounded-md bg-warn-soft p-3 text-sm text-warn",
					children: [
						n.bn,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block mt-1 text-muted",
							children: n.en
						})
					]
				}, n.en))
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-muted",
			children: "কোনো শব্দ মেলেনি।"
		})
	] });
}
//#endregion
export { Words as component };
