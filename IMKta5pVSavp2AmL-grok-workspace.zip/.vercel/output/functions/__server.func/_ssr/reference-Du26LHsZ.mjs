import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as chapters } from "./lessons-DRFcRenz.mjs";
import { t as RuleBlock } from "./rule-block-DsX2vrq5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reference-Du26LHsZ.js
var import_jsx_runtime = require_jsx_runtime();
function Reference() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-semibold",
			children: "সব নিয়ম এক নজরে"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "bn mt-2 max-w-2xl text-muted",
			children: "বইয়ের §308 থেকে §347 — কোনো নিয়ম বা ব্যতিক্রম বাদ নেই। অফলাইনে পড়ার জন্য এই পাতাই পুরো পাঠ্য।"
		}),
		chapters.map((ch) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-2xl font-semibold",
					children: [
						ch.index,
						". ",
						ch.titleEn
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "bn text-muted",
					children: ch.titleBn
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 space-y-4",
					children: ch.sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleBlock, { section: s }, s.id))
				})
			]
		}, ch.id))
	] });
}
//#endregion
export { Reference as component };
